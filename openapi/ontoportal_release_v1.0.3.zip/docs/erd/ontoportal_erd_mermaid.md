```mermaid
flowchart TD
  O[Ontology] -->|1..N| C[Class]
  C -->|0..N| Cat[Category]
```